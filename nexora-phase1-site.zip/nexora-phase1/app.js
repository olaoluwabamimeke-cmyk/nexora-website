const sampleBusinesses = [
  {id:1,name:"PixelCraft Digital",category:"Technology & Digital Services",city:"Ibadan",state:"Oyo",description:"Sample listing — website design, digital tools, and online business support.",initials:"P",cover:"digital",phone:"",whatsapp:""},
  {id:2,name:"Thread & Form Studio",category:"Fashion & Clothing",city:"Lagos",state:"Lagos",description:"Sample listing — made-to-order clothing and everyday style essentials.",initials:"T",cover:"fashion",phone:"",whatsapp:""},
  {id:3,name:"The Good Bowl",category:"Food & Restaurants",city:"Abuja",state:"FCT",description:"Sample listing — a demonstration food brand for this website preview.",initials:"G",cover:"food",phone:"",whatsapp:""},
  {id:4,name:"Glow Room Beauty",category:"Beauty & Personal Care",city:"Osogbo",state:"Osun",description:"Sample listing — beauty services and personal-care appointments.",initials:"G",cover:"beauty",phone:"",whatsapp:""},
  {id:5,name:"Buildwise Services",category:"Construction & Building",city:"Ibadan",state:"Oyo",description:"Sample listing — building maintenance and home improvement services.",initials:"B",cover:"services",phone:"",whatsapp:""},
  {id:6,name:"Everyday Finds",category:"Retail & Shopping",city:"Lagos",state:"Lagos",description:"Sample listing — a sample retailer showcasing household essentials.",initials:"E",cover:"retail",phone:"",whatsapp:""}
];
const grid = document.getElementById("businessGrid");
const searchInput = document.getElementById("searchInput");
const locationFilter = document.getElementById("locationFilter");
let activeCategory = "All";

function safeText(value){return String(value ?? "").replace(/[&<>"']/g, ch => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[ch]));}
function renderBusinesses(){
  const q = searchInput.value.trim().toLowerCase();
  const city = locationFilter.value;
  const items = sampleBusinesses.filter(b => {
    const matchesCategory = activeCategory === "All" || b.category === activeCategory;
    const matchesCity = city === "All" || b.city === city;
    const haystack = [b.name,b.category,b.city,b.state,b.description].join(" ").toLowerCase();
    return matchesCategory && matchesCity && (!q || haystack.includes(q));
  });
  grid.innerHTML = "";
  if(!items.length){
    grid.innerHTML = '<div class="empty-state"><strong>No matching listings yet.</strong><p>Try another search term or clear your filters.</p><button class="button button-dark" id="emptyClear">Clear filters ↺</button></div>';
    document.getElementById("emptyClear").addEventListener("click", clearFilters);
  } else {
    items.forEach(b => {
      const card = document.createElement("article");
      card.className = "business-card";
      card.innerHTML = `<div class="business-cover cover-${safeText(b.cover)}"><span class="sample-pill">SAMPLE LISTING</span><span class="business-monogram">${safeText(b.initials)}</span></div>
        <div class="business-body"><span class="business-category">${safeText(b.category)}</span><h3>${safeText(b.name)}</h3><div class="business-location">⌖ ${safeText(b.city)}, ${safeText(b.state)}</div><p class="business-description">${safeText(b.description)}</p>
        <div class="business-actions"><button class="view-button" data-profile="${b.id}">View details ↗</button><button disabled title="Contact details are not configured for sample listings">Contact unavailable</button></div></div>`;
      grid.appendChild(card);
    });
    grid.querySelectorAll("[data-profile]").forEach(btn => btn.addEventListener("click", () => showBusinessDetails(Number(btn.dataset.profile))));
  }
  document.getElementById("resultCount").textContent = `Showing ${items.length} sample ${items.length === 1 ? "listing" : "listings"}`;
}
function showBusinessDetails(id){
  const b = sampleBusinesses.find(x => x.id === id);
  if(!b) return;
  const info = document.getElementById("infoModal");
  document.getElementById("infoTitle").textContent = b.name;
  document.getElementById("infoText").textContent = `${b.category} · ${b.city}, ${b.state}. ${b.description} This is demonstration data only. No real contact details or verification are available in this preview.`;
  info.showModal();
}
function clearFilters(){
  searchInput.value = "";
  locationFilter.value = "All";
  activeCategory = "All";
  document.querySelectorAll(".filter-tab").forEach(b => b.classList.toggle("active", b.dataset.filter === "All"));
  renderBusinesses();
}
document.getElementById("searchForm").addEventListener("submit", e => {e.preventDefault();renderBusinesses();document.getElementById("businesses").scrollIntoView({behavior:"smooth"});});
searchInput.addEventListener("input", renderBusinesses);
locationFilter.addEventListener("change", renderBusinesses);
document.querySelectorAll(".filter-tab").forEach(btn => btn.addEventListener("click", () => {
  activeCategory = btn.dataset.filter;
  document.querySelectorAll(".filter-tab").forEach(b => b.classList.toggle("active", b === btn));
  renderBusinesses();
}));
document.querySelectorAll(".category-card").forEach(btn => btn.addEventListener("click", () => {
  const category = btn.dataset.category;
  if(category === "Agriculture" || category === "Skills & Training"){
    const info = document.getElementById("infoModal");
    document.getElementById("infoTitle").textContent = category + " — coming soon";
    document.getElementById("infoText").textContent = `The ${category.toLowerCase()} area is part of the NEXORA roadmap, but its listing and submission backend has not been implemented in this preview.`;
    info.showModal();
    return;
  }
  if(category === "Products & Marketplace"){
    const info = document.getElementById("infoModal");
    document.getElementById("infoTitle").textContent = "Marketplace — coming soon";
    document.getElementById("infoText").textContent = "The product marketplace is planned for a later phase. This preview focuses on the business directory.";
    info.showModal();
    return;
  }
  activeCategory = "All";
  searchInput.value = "";
  document.querySelectorAll(".filter-tab").forEach(b => b.classList.toggle("active", b.dataset.filter === "All"));
  document.getElementById("businesses").scrollIntoView({behavior:"smooth"});
  renderBusinesses();
}));
document.querySelectorAll("[data-open-modal]").forEach(btn => btn.addEventListener("click", () => {
  document.getElementById("formFeedback").textContent = "";
  document.getElementById("formFeedback").className = "form-feedback";
  document.getElementById("businessModal").showModal();
}));
function closeBusinessModal(){document.getElementById("businessModal").close();}
document.getElementById("closeModal").addEventListener("click",closeBusinessModal);
document.getElementById("cancelModal").addEventListener("click",closeBusinessModal);
document.getElementById("businessForm").addEventListener("submit", e => {
  e.preventDefault();
  const form = e.currentTarget;
  const feedback = document.getElementById("formFeedback");
  if(!form.reportValidity()){
    feedback.className = "form-feedback error";
    feedback.textContent = "Please complete all required fields and check that the email address is valid.";
    return;
  }
  const phone = form.elements.phone.value.trim();
  const wa = form.elements.whatsapp.value.trim();
  if(!/^[+\d][\d\s().-]{6,20}$/.test(phone) || (wa && !/^[+\d][\d\s().-]{6,20}$/.test(wa))){
    feedback.className = "form-feedback error";
    feedback.textContent = "Please enter a valid phone number. Include the country code, for example +234.";
    return;
  }
  feedback.className = "form-feedback success";
  feedback.textContent = "Form validation passed. This is only a front-end preview: your details have NOT been sent or saved. Supabase/backend setup is required before accepting real submissions.";
});
document.getElementById("clearFilters").addEventListener("click",clearFilters);
document.getElementById("closeInfo").addEventListener("click",()=>document.getElementById("infoModal").close());
document.querySelectorAll("[data-info]").forEach(a => a.addEventListener("click", e => {
  e.preventDefault();
  const title = a.dataset.info;
  document.getElementById("infoTitle").textContent = title;
  document.getElementById("infoText").textContent = title === "Privacy Policy"
    ? "NEXORA should collect only information needed to operate accounts and business listings, explain how information is used, protect private account data, and provide a way to request access or deletion. This starter preview does not collect or transmit form data. A final policy must reflect the actual backend, hosting, analytics, and data retention practices."
    : "Users should provide accurate listing information, respect others, and not submit fraudulent, harmful, or misleading content. NEXORA should reserve the right to review and moderate listings under a transparent process. Final terms, dispute procedures, and liability provisions need legal review before launch.";
  document.getElementById("infoModal").showModal();
}));
const menuToggle = document.getElementById("menuToggle");
const mainNav = document.getElementById("mainNav");
menuToggle.addEventListener("click", () => {
  const open = mainNav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(open));
  menuToggle.setAttribute("aria-label", open ? "Close navigation" : "Open navigation");
  menuToggle.textContent = open ? "×" : "☰";
});
mainNav.querySelectorAll("a").forEach(a => a.addEventListener("click",()=>{mainNav.classList.remove("open");menuToggle.setAttribute("aria-expanded","false");menuToggle.textContent="☰";}));
document.getElementById("year").textContent = new Date().getFullYear();
renderBusinesses();
